package GameRanks;

import java.util.Scanner;

class Player {
    int id;
    String name;
    int score;
    int level;

    Player(int id, String name, int score, int level) {
        this.id = id;
        this.name = name;
        this.score = score;
        this.level = level;
    }
}

class Node {
    String action;
    Node next;

    public Node(String action) {
        this.action = action;
        this.next = null;
    }
}

class SimpleStack {
    String[] items = new String[100];
    int top = -1;

    public void push(String action) {
        if (top < items.length - 1) {
            top++; 
            items[top] = action;
        } else {
            System.out.println("Undo stack is full!");
        }
    }

    public String pop() {
        if (!isEmpty()) {
            String action = items[top];
            top--; 
            return action;
        }
        return null;
    }

    public boolean isEmpty() {
        return top == -1;
    }
}

class SimpleQueue {
    String[] items = new String[100];
    int front = 0;
    int rear = 0;

    public void add(String name) {
        if (rear < items.length) {
            items[rear] = name;
            rear++; 
        } else {
            System.out.println("Matchmaking queue is full!");
        }
    }

    public String poll() {
        if (!isEmpty()) {
            String name = items[front];
            front++; 
            return name;
        }
        return null;
    }

    public boolean isEmpty() {
        return front == rear;
    }
}

class Game {
    Player[] players;
    int playerCount;

    Node historyHead;
    SimpleStack undoStack;   
    SimpleQueue matchQueue;  

    public Game() {
        players = new Player[100];
        playerCount = 0;
        historyHead = null;
        undoStack = new SimpleStack();     
        matchQueue = new SimpleQueue(); 
    }

    public void addPlayer(int id, String name, int score, int level) {
        if (playerCount < players.length) {
            players[playerCount] = new Player(id, name, score, level);
            playerCount++;

            addHistory("Added Player: " + name);
            undoStack.push("Add " + name);
        } else {
            System.out.println("Leaderboard is full!");
        }
    }

    public void displayPlayers() {
        System.out.println("\n--- Current Leaderboard ---");
        if (playerCount == 0) {
            System.out.println("No players yet.");
            return;
        }
        for (int i = 0; i < playerCount; i++) {
            Player p = players[i];
            System.out.println("ID: " + p.id + " | " + p.name +
                               " | Score: " + p.score + " | Lvl: " + p.level);
        }
    }

    public void sortPlayers() {
        if (playerCount > 1) {
            mergeSort(0, playerCount - 1);
            System.out.println("\nLeaderboard sorted.");
            addHistory("Sorted leaderboard");
        } else {
            System.out.println("\nNot enough players to sort.");
        }
        displayPlayers();
    }

    public void mergeSort(int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(left, mid);
            mergeSort(mid + 1, right);
            merge(left, mid, right);
        }
    }

    public void merge(int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        Player[] L = new Player[n1];
        Player[] R = new Player[n2];

        for (int i = 0; i < n1; i++) L[i] = players[left + i];
        for (int j = 0; j < n2; j++) R[j] = players[mid + 1 + j];

        int i = 0, j = 0, k = left;

        while (i < n1 && j < n2) {
            if (L[i].score >= R[j].score) {
                players[k++] = L[i++];
            } else {
                players[k++] = R[j++];
            }
        }
        while (i < n1) players[k++] = L[i++];
        while (j < n2) players[k++] = R[j++];
    }
    public void searchPlayer(int id) {
        for (int i = 0; i < playerCount; i++) {
            if (players[i].id == id) {
                System.out.println("Found -> " + players[i].name + " (Score: " + players[i].score + ")");
                return;
            }
        }
        System.out.println("No player with that ID.");
    }

    public void addHistory(String action) {
        Node newNode = new Node(action);
        newNode.next = historyHead;
        historyHead = newNode;
    }

    public void displayHistory() {
        System.out.println("\n--- Action History ---");
        Node temp = historyHead;
        if (temp == null) {
            System.out.println("No history yet.");
            return;
        }
        while (temp != null) {
            System.out.println("- " + temp.action);
            temp = temp.next;
        }
    }

    public void undo() {
        if (!undoStack.isEmpty()) {
            String lastAction = undoStack.pop();
            System.out.println("Undoing: " + lastAction);
            
            // Actually undo the addition of the player
            if (lastAction.startsWith("Add ")) {
                if (playerCount > 0) {
                    playerCount--; // This "removes" the player from the array logic
                    System.out.println("Successfully removed the last added player.");
                    addHistory("Undid action: " + lastAction);
                }
            }
        } else {
            System.out.println("Nothing left to undo.");
        }
    }

    public void addToQueue(String name) {
        matchQueue.add(name);
        System.out.println(name + " joined matchmaking.");
        addHistory(name + " joined queue");
    }

    public void processQueue() {
        if (!matchQueue.isEmpty()) {
            String matchedPlayer = matchQueue.poll();
            System.out.println("Now matching: " + matchedPlayer);
            addHistory("Matched player: " + matchedPlayer);
        } else {
            System.out.println("Queue is empty.");
        }
    }
}

public class GameLeaderboard {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Game game = new Game(); 
        boolean running = true;

        while (running) {
            System.out.println("\n1. Add Player");
            System.out.println("2. Display Leaderboard");
            System.out.println("3. Sort Players");
            System.out.println("4. Search Player by ID");
            System.out.println("5. Show History");
            System.out.println("6. Undo Last Action");
            System.out.println("7. Add Player to Matchmaking");
            System.out.println("8. Process Matchmaking");
            System.out.println("9. Exit");
            System.out.print("Choose: ");

            int choice = sc.nextInt();
            switch (choice) {
            case 1:
                System.out.print("Enter ID: ");
                int id = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter Name: ");
                String name = sc.nextLine();
                System.out.print("Enter Score: ");
                int score = sc.nextInt();
                System.out.print("Enter Level: ");
                int level = sc.nextInt();
                game.addPlayer(id, name, score, level);
                break;
            case 2:
                game.displayPlayers();
                break;
            case 3:
                game.sortPlayers();
                break;
            case 4:
                System.out.print("Enter Player ID: ");
                game.searchPlayer(sc.nextInt());
                break;
            case 5:
                game.displayHistory();
                break;
            case 6:
                game.undo();
                break;
            case 7:
                sc.nextLine();
                System.out.print("Enter Player Name: ");
                game.addToQueue(sc.nextLine());
                break;
            case 8:
                game.processQueue();
                break;
            case 9:
                System.out.println("Exiting...");
                running = false;
                break;
            default:
                System.out.println("Invalid option.");
        }
    }
    sc.close();
}
}